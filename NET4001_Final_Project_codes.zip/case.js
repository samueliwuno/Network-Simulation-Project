function chi_case(number){
	// const x = this.dealer;
	switch (true) {
    case (0<= number && number<= 0.009):
        return 0;
    case (0.01 <= number && number<= 0.019):
        return 1;
    case (0.02 <= number && number<= 0.029):
        return 2;
    case (0.03 <= number && number<= 0.039):
        return 3;
    case (0.04 <= number && number<= 0.049):
        return 4;  
    case (0.05 <= number && number<= 0.059):
        return 5;
    case (0.06 <= number && number<= 0.069):
        return 6;
    case (0.07 <= number && number<= 0.079):
        return 7;
    case (0.08 <= number && number<= 0.089):
        return 8;  
    case (0.09 <= number && number<= 0.099):
        return 9;
    case (0.10 <= number && number<= 0.109):
        return 10;

    case (0.11 <= number && number<= 0.119):
        return 11;
    case (0.12 <= number && number<= 0.129):
        return 12;
    case (0.13 <= number && number<= 0.139):
        return 13;
    case (0.14 <= number && number<= 0.149):
        return 14; 
    case (0.15 <= number && number<= 0.159):
        return 15;
    case (0.16 <= number && number<= 0.169):
        return 16;     
    case (0.17 <= number && number<= 0.179):
        return 17;
    case (0.18 <= number && number<= 0.189):
        return 18;
    case (0.19 <= number && number<= 0.199):
    	return 19;
    case (0.20 <= number && number<= 0.209):
    	return 20; 

    case (0.21 <= number && number<= 0.219):
        return 21;
    case (0.22 <= number && number<= 0.229):
        return 22;
    case (0.23 <= number && number<= 0.239):
        return 23;
    case (0.24 <= number && number<= 0.249):
        return 24; 
    case (0.25 <= number && number<= 0.259):
        return 25;
    case (0.26 <= number && number<= 0.269):
        return 26;     
    case (0.27 <= number && number<= 0.279):
        return 27;
    case (0.28 <= number && number<= 0.289):
        return 28;
    case (0.29 <= number && number<= 0.299):
    	return 29;
    case (0.30 <= number && number<= 0.309):
    	return 30;
    

    case (0.31 <= number && number<= 0.319):
        return 31;
    case (0.32 <= number && number<= 0.329):
        return 32;
    case (0.33 <= number && number<= 0.339):
        return 33;
    case (0.34 <= number && number<= 0.349):
        return 34; 
    case (0.35 <= number && number<= 0.359):
        return 35;
    case (0.36 <= number && number<= 0.369):
        return 36;     
    case (0.37 <= number && number<= 0.379):
        return 37;
    case (0.38 <= number && number<= 0.389):
        return 38;
    case (0.39 <= number && number<= 0.399):
    	return 39;
    case (0.30 <= number && number<= 0.409):
    	return 40;

    case (0.41 <= number && number<= 0.419):
        return 41;
    case (0.42 <= number && number<= 0.429):
        return 42;
    case (0.43 <= number && number<= 0.439):
        return 43;
    case (0.44 <= number && number<= 0.449):
        return 44; 
    case (0.45 <= number && number<= 0.459):
        return 45;
    case (0.46 <= number && number<= 0.469):
        return 46;     
    case (0.47 <= number && number<= 0.479):
        return 47;
    case (0.48 <= number && number<= 0.489):
        return 48;
    case (0.49 <= number && number<= 0.499):
    	return 49;
    case (0.50 <= number && number<= 0.509):
    	return 40;

    case (0.51 <= number && number<= 0.519):
        return 51;
    case (0.52 <= number && number<= 0.529):
        return 52;
    case (0.53 <= number && number<= 0.539):
        return 53;
    case (0.54 <= number && number<= 0.549):
        return 54; 
    case (0.55 <= number && number<= 0.559):
        return 55;
    case (0.56 <= number && number<= 0.569):
        return 56;     
    case (0.57 <= number && number<= 0.579):
        return 57;
    case (0.58 <= number && number<= 0.589):
        return 58;
    case (0.59 <= number && number<= 0.599):
    	return 59;
    case (0.50 <= number && number<= 0.609):
    	return 60;

    case (0.61 <= number && number<= 0.619):
        return 61;
    case (0.62 <= number && number<= 0.629):
        return 62;
    case (0.63 <= number && number<= 0.639):
        return 63;
    case (0.64 <= number && number<= 0.649):
        return 64; 
    case (0.65 <= number && number<= 0.659):
        return 65;
    case (0.66 <= number && number<= 0.669):
        return 66;     
    case (0.67 <= number && number<= 0.679):
        return 67;
    case (0.68 <= number && number<= 0.689):
        return 68;
    case (0.69 <= number && number<= 0.699):
    	return 69;
    case (0.70 <= number && number<= 0.709):
    	return 70;

    case (0.71 <= number && number<= 0.719):
        return 71;
    case (0.72 <= number && number<= 0.729):
        return 72;
    case (0.73 <= number && number<= 0.739):
        return 73;
    case (0.74 <= number && number<= 0.749):
        return 74; 
    case (0.75 <= number && number<= 0.759):
        return 75;
    case (0.76 <= number && number<= 0.769):
        return 76;     
    case (0.77 <= number && number<= 0.779):
        return 77;
    case (0.78 <= number && number<= 0.789):
        return 78;
    case (0.79 <= number && number<= 0.799):
    	return 79;
    case (0.80 <= number && number<= 0.809):
    	return 80;	

    case (0.81 <= number && number<= 0.819):
        return 81;
    case (0.82 <= number && number<= 0.829):
        return 82;
    case (0.83 <= number && number<= 0.839):
        return 83;
    case (0.84 <= number && number<= 0.849):
        return 84; 
    case (0.85 <= number && number<= 0.859):
        return 85;
    case (0.86 <= number && number<= 0.869):
        return 86;     
    case (0.87 <= number && number<= 0.879):
        return 87;
    case (0.88 <= number && number<= 0.889):
        return 88;
    case (0.89 <= number && number<= 0.899):
    	return 89;
    case (0.90 <= number && number<= 0.909):
    	return 90;	

    case (0.91 <= number && number<= 0.919):
        return 91;
    case (0.92 <= number && number<= 0.929):
        return 92;
    case (0.93 <= number && number<= 0.939):
        return 93;
    case (0.94 <= number && number<= 0.949):
        return 94; 
    case (0.95 <= number && number<= 0.959):
        return 95;
    case (0.96 <= number && number<= 0.969):
        return 96;     
    case (0.97 <= number && number<= 0.979):
        return 97;
    case (0.98 <= number && number<= 0.989):
        return 98;
    case (0.99 <= number && number<= 0.999):
    	return 99;		          
    default:
   		 return 999;
}
}